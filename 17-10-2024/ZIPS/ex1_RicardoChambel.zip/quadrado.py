"""

    lado: int
    cor: str

"""

class Quadrado:
    def __init__(self, lado, cor):
        self.lado = lado
        self.cor = cor