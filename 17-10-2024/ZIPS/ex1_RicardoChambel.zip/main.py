from quadrado import Quadrado
from triangulo import Triangulo
from trapezio import Trapezio
from circulo import Circulo

q1 = Quadrado(20, "Amarelo")

q2 = Quadrado(34, "Azul")

"""
Criar base para a class

triangulo
circulo
trapezio

"""
# Triangulos
t1 = Triangulo(20, 20, "Roxo")

t2 = Triangulo(34, 20, "Vermelho")

# Trapezios
t1 = Trapezio(20, 20, 20, "Preto")

t2 = Trapezio(34, 30, 20, "Branco")

# Circulo
t1 = Circulo(10, "Laranja")

t2 = Circulo(14, "Rosa")