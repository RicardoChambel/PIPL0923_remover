"""
    lado: int
    cor: str

"""

class Triangulo:
    def __init__(self, base, altura, cor):
        self.base = base
        self.altura = altura
        self.cor = cor