"""

    lado: int
    cor: str

"""

class Trapezio:
    def __init__(self, base, altura, lados, cor):
        self.base = base
        self.altura = altura
        self.lados = lados
        self.cor = cor