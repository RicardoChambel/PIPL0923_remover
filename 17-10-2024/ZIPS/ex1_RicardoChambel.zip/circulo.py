"""

    lado: int
    cor: str

"""

class Circulo:
    def __init__(self, raio, cor):
        self.raio = raio
        self.cor = cor